Everything is coded from scratch

To run:
 Open the project in Unity
 Open the scene file
 press Run

press 'r' to restart scene

Resources : contains all assets used in the project
Scripts:
	CircleCollide: Collider for the fish
	obstacle: obstacle object
	main: control everything
	EulerSolver: solving velocity acceleration and position
	Constants: constants in the game
	Rule: Pursuit and evade behaviour


Video: https://youtu.be/Q6Kemd-3E00